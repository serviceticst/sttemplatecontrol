<?php

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access this file directly");
}

use Glpi\Application\View\TemplateRenderer;

/**
 * Configuration tab displayed in Setup > General.
 */
class PluginSttemplatecontrolConfig extends Config
{
    public const CONTEXT = 'plugin:sttemplatecontrol';
    private const DOMAIN = 'sttemplatecontrol';

    public static $rightname = 'config';

    /** @var array<string, int>|null */
    private static ?array $runtimeConfig = null;

    public static function getTypeName($nb = 0): string
    {
        return 'ST Template Control';
    }

    public static function getIcon(): string
    {
        return 'ti ti-arrows-sort';
    }

    /**
     * @return array<string, int>
     */
    public static function getDefaultConfig(): array
    {
        return [
            'enabled'                  => 1,
            'apply_ticket'             => 1,
            'apply_change'             => 1,
            'apply_problem'            => 1,
            'clear_template_on_update' => 1,
            'debug'                    => 0,
        ];
    }

    /**
     * @return array<string, int>
     */
    public static function getConfig(): array
    {
        if (self::$runtimeConfig !== null) {
            return self::$runtimeConfig;
        }

        $saved = Config::getConfigurationValues(self::CONTEXT);
        $config = self::getDefaultConfig();

        foreach (array_keys($config) as $key) {
            $config[$key] = (int) ($saved[$key] ?? $config[$key]);
        }

        self::$runtimeConfig = $config;

        return self::$runtimeConfig;
    }

    /**
     * Sanitize the values posted by the generic GLPI configuration form.
     *
     * Defining this method also prevents the helper field "config_class"
     * from being persisted as a plugin setting by Config::prepareInputForUpdate().
     *
     * @param array<string, mixed> $input
     *
     * @return array<string, int>
     */
    public static function configUpdate(array $input): array
    {
        $sanitized = [];

        foreach (array_keys(self::getDefaultConfig()) as $key) {
            $sanitized[$key] = ((int) ($input[$key] ?? 0) === 1) ? 1 : 0;
        }

        self::resetRuntimeCache();

        return $sanitized;
    }

    public static function resetRuntimeCache(): void
    {
        self::$runtimeConfig = null;
    }

    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0): string
    {
        if ($item instanceof Config && Session::haveRight(self::$rightname, READ)) {
            return self::createTabEntry(self::getTypeName(), 0, self::class);
        }

        return '';
    }

    public static function displayTabContentForItem(
        CommonGLPI $item,
        $tabnum = 1,
        $withtemplate = 0
    ): bool {
        if ($item instanceof Config) {
            return self::showForConfig($item);
        }

        return false;
    }

    /**
     * Keep all user-facing strings in PHP so the plugin can use GLPI's gettext
     * domain consistently, while the Twig template stays presentation-only.
     *
     * @return array<string, string>
     */
    private static function getTranslations(): array
    {
        return [
            'description' => __('Controls persistent template bindings in GLPI, allowing native template selection based on category, active profile, and entity.', self::DOMAIN),
            'mode_title' => __('Implemented mode: GLPI 10 compatibility.', self::DOMAIN),
            'mode_text' => __('The template stored on the ticket, change or problem is no longer treated as a forced template, restoring GLPI 10-style behaviour.', self::DOMAIN),
            'native_order_intro' => __('GLPI resolves the native order again:', self::DOMAIN),
            'native_order' => __('Category → Active profile → Entity', self::DOMAIN),
            'user_origin_text' => __('The native GLPI 10/11 code does not provide a direct template source linked to the user.', self::DOMAIN),
            'profile_origin_text' => __('The profile template is read from the active profile of the signed-in user. Therefore, this plugin does not expose a fictitious “User” option in the precedence order.', self::DOMAIN),
            'enabled' => __('Enable template compatibility', self::DOMAIN),
            'apply_ticket' => __('Apply to tickets', self::DOMAIN),
            'apply_change' => __('Apply to changes', self::DOMAIN),
            'apply_problem' => __('Apply to problems', self::DOMAIN),
            'clear_template_on_update' => __('Clear persisted template link on updates', self::DOMAIN),
            'debug' => __('Enable debug logging', self::DOMAIN),
            'debug_hint' => __('When debug logging is enabled, GLPI writes the file:', self::DOMAIN),
            'save' => __('Save', self::DOMAIN),
            'read_only' => __('Your profile has read permission, but not permission to change the general settings.', self::DOMAIN),
            'developed_by' => __('Developed by:', self::DOMAIN),
            'website_link_title' => __('Visit the Service TIC website', self::DOMAIN),
            'links_link_title' => __('Open Service TIC links', self::DOMAIN),
            'logo_alt' => __('Service TIC logo', self::DOMAIN),
            'qrcode_alt' => __('QR code for Service TIC links', self::DOMAIN),
        ];
    }

    /**
     * Return the local Service TIC assets and external destination links used
     * by the attribution panel. Images are shipped under pics/ and public/pics/.
     *
     * @return array<string, string>
     */
    private static function getMarketingData(): array
    {
        global $CFG_GLPI;

        $rootDoc = rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/');
        $assetBaseUrl = $rootDoc . '/plugins/sttemplatecontrol/pics';

        return [
            'logo_url'    => $assetBaseUrl . '/service_tic_logo.png',
            'qrcode_url'  => $assetBaseUrl . '/service_tic_qrcode.png',
            'website_url' => 'https://www.servicetic.com.br',
            'links_url'   => 'https://servicetic.com.br/links',
        ];
    }

    public static function showForConfig(Config $config): bool
    {
        if (!Session::haveRight(self::$rightname, READ)) {
            return false;
        }

        TemplateRenderer::getInstance()->display('@sttemplatecontrol/config.html.twig', [
            'current_config' => self::getConfig(),
            'can_edit'       => Session::haveRight(self::$rightname, UPDATE),
            'config_class'   => self::class,
            'config_context' => self::CONTEXT,
            'i18n'           => self::getTranslations(),
            'marketing'      => self::getMarketingData(),
        ]);

        return true;
    }
}
