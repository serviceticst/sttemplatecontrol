<?php

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access this file directly");
}

/**
 * Implements GLPI 10-compatible template handling for ITIL objects.
 *
 * GLPI 11 stores the selected template foreign key in the ITIL object. When
 * an existing object is shown, that persisted value is used by showForm() as
 * the fallback value for "template_preview", which makes it a forced template.
 *
 * The PRE_SHOW_ITEM hook exposes the form options by reference. By explicitly
 * setting template_preview to 0 when no preview was requested, this plugin
 * reproduces the GLPI 10 call path without mutating the item object in memory.
 * It also prevents new template foreign keys from remaining persisted.
 */
class PluginSttemplatecontrolTemplateHandler
{
    /**
     * Called immediately before CommonITILObject::showForm().
     *
     * GLPI builds the hook payload with "options" as a reference. Although the
     * outer hook payload is passed by value to this callback, PHP preserves the
     * referenced nested value, so this assignment changes the options received
     * by showForm().
     *
     * @param array{item?: mixed, options?: array<string, mixed>} $params
     */
    public static function preShowItem(array $params): void
    {
        $item = $params['item'] ?? null;
        if (!$item instanceof CommonITILObject || !self::isEnabledFor($item)) {
            return;
        }

        // A real preview request is intentional and must retain top priority.
        $explicit_preview = (int) ($params['options']['template_preview'] ?? 0);
        if ($explicit_preview > 0) {
            self::debug(
                $item,
                sprintf('Explicit preview preserved: template %d.', $explicit_preview)
            );
            return;
        }

        $field = self::getTemplateForeignKeyField($item);
        $persisted_template = $field === null
            ? 0
            : (int) ($item->fields[$field] ?? 0);

        // This is the decisive GLPI 10 compatibility behavior. In GLPI 10,
        // normal rendering passed "template_preview ?? 0". Defining the option
        // as 0 prevents GLPI 11 from falling back to the persisted foreign key.
        $params['options']['template_preview'] = 0;

        if ($persisted_template > 0) {
            self::debug(
                $item,
                sprintf(
                    'Persisted template %d ignored during display; native resolution released to Category > Active profile > Entity.',
                    $persisted_template
                )
            );
        }
    }

    /**
     * Called after prepareInputForAdd() and before the database INSERT.
     */
    public static function postPrepareAdd(CommonITILObject $item): void
    {
        if (!self::isEnabledFor($item) || !is_array($item->input)) {
            return;
        }

        $field = self::getTemplateForeignKeyField($item);
        if ($field === null || !array_key_exists($field, $item->input)) {
            return;
        }

        $template_id = (int) $item->input[$field];
        unset($item->input[$field]);

        // Keep the legacy _tickettemplate/_changetemplate/_problemtemplate input.
        // Other core routines may still use it during the current creation flow.
        self::debug(
            $item,
            sprintf(
                'Template %d removed from INSERT; values already applied by the form are preserved.',
                $template_id
            )
        );
    }

    /**
     * Called before prepareInputForUpdate().
     */
    public static function preItemUpdate(CommonITILObject $item): void
    {
        if (!self::isEnabledFor($item) || !is_array($item->input)) {
            return;
        }

        $field = self::getTemplateForeignKeyField($item);
        if ($field === null) {
            return;
        }

        $form_field = $item::getTemplateFormFieldName();
        unset($item->input[$field], $item->input[$form_field]);

        // If the GLPI core recalculates the template because category/entity/type
        // changed, avoid generating a misleading history entry for an internal
        // value that this plugin will clear immediately after the update.
        if (!in_array($field, $item->history_blacklist, true)) {
            $item->history_blacklist[] = $field;
        }
    }

    /**
     * Called after the core UPDATE. There is no public post-prepare-update hook
     * in GLPI 11, so the optional persistence cleanup is intentionally done here.
     */
    public static function itemUpdate(CommonITILObject $item): void
    {
        global $DB;

        if (!self::isEnabledFor($item)) {
            return;
        }

        $config = PluginSttemplatecontrolConfig::getConfig();
        if (empty($config['clear_template_on_update'])) {
            return;
        }

        $field = self::getTemplateForeignKeyField($item);
        if ($field === null || !$item->getID()) {
            return;
        }

        $current_value = (int) ($item->fields[$field] ?? 0);
        if ($current_value <= 0) {
            return;
        }

        $table = $item::getTable();
        if (!$DB->fieldExists($table, $field)) {
            self::debug($item, sprintf('Field %s does not exist in %s; cleanup skipped.', $field, $table));
            return;
        }

        $updated = $DB->update(
            $table,
            [$field => 0],
            [$item::getIndexName() => $item->getID()]
        );

        if ($updated) {
            $item->fields[$field] = 0;

            if (is_array($item->input)) {
                unset($item->input[$field]);
            }
            if (is_array($item->oldvalues)) {
                unset($item->oldvalues[$field]);
            }
            if (is_array($item->updates)) {
                $item->updates = array_values(
                    array_filter(
                        $item->updates,
                        static fn(mixed $updated_field): bool => $updated_field !== $field
                    )
                );
            }

            self::debug(
                $item,
                sprintf('Persisted template %d cleared after update.', $current_value)
            );
        } else {
            self::debug(
                $item,
                sprintf('Failed to clear persisted template %d after update.', $current_value)
            );
        }
    }

    private static function isEnabledFor(CommonITILObject $item): bool
    {
        $config = PluginSttemplatecontrolConfig::getConfig();
        if (empty($config['enabled'])) {
            return false;
        }

        if ($item instanceof Ticket) {
            return !empty($config['apply_ticket']);
        }
        if ($item instanceof Change) {
            return !empty($config['apply_change']);
        }
        if ($item instanceof Problem) {
            return !empty($config['apply_problem']);
        }

        return false;
    }

    private static function getTemplateForeignKeyField(CommonITILObject $item): ?string
    {
        $template_class = $item::getTemplateClass();
        if (!class_exists($template_class) || !method_exists($template_class, 'getForeignKeyField')) {
            return null;
        }

        return $template_class::getForeignKeyField();
    }

    private static function debug(CommonITILObject $item, string $message): void
    {
        $config = PluginSttemplatecontrolConfig::getConfig();
        if (empty($config['debug'])) {
            return;
        }

        Toolbox::logInFile(
            'sttemplatecontrol',
            sprintf(
                '[%s #%d] %s%s',
                $item->getType(),
                (int) $item->getID(),
                $message,
                PHP_EOL
            )
        );
    }
}
