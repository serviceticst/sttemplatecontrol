<?php

include '../../../inc/includes.php';

Session::checkRight('config', READ);

Html::redirect(
    $CFG_GLPI['root_doc']
    . '/front/config.form.php?forcetab=PluginSttemplatecontrolConfig$1'
);
