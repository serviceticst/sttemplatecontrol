# Attribution / Créditos

**ST Template Control — 2.0.0**  
**Authors / Autores: Service TIC (fork) / Curtis Conard**

## Upstream project / Projeto original

**Unstick ITIL Templates**, by **Curtis Conard** (`cconard96`).

- Repository / Repositório: https://github.com/cconard96/glpi-unsticktemplates-plugin
- Original source notice / Aviso do código original:

```text
SPDX-FileCopyrightText: 2026 Curtis Conard
SPDX-License-Identifier: GPL-3.0-or-later
```

The upstream project provides the original approach of removing the persisted
ITIL template link during item creation. ST Template Control is the Service TIC
fork/adaptation, with additional configuration, display handling, update handling,
translations and documentation.

O projeto original fornece a abordagem de remover o vínculo persistido do modelo
ITIL durante a criação do item. ST Template Control é o fork/adaptação da Service
TIC, com configurações, tratamento de exibição e atualização, traduções e
documentação adicionais.

## Fork / Adaptação

Copyright (C) 2026 Service TIC Soluções Tecnológicas.

This 2.0.0 package, prepared on 2026-10-08, adopts the ST Template Control name,
updated description and `sttemplatecontrol` internal identity. It retains the
previous fork's template-handling logic and configuration defaults. Author credits,
bilingual READMEs and compiled translation catalogues are included. No plugin table
or database schema migration is introduced.

Este pacote 2.0.0, preparado em 08/10/2026, adota o nome ST Template Control, a nova
descrição e a identidade interna `sttemplatecontrol`. Preserva a lógica de tratamento
de modelos e os valores padrão do fork anterior. Inclui créditos dos autores,
READMEs bilíngues e traduções compiladas. Não cria tabelas do plugin nem altera o
esquema do banco de dados.

The prior `sttemplatepriority` identity is documented only for replacement guidance;
its saved settings are not automatically migrated. See the READMEs before switching.

A identidade anterior `sttemplatepriority` aparece apenas como referência de
substituição; suas configurações não são migradas automaticamente. Consulte os
READMEs antes da troca.

## License / Licença

GPL-3.0-or-later. The full license is included in [LICENSE](LICENSE).
A licença completa está incluída em [LICENSE](LICENSE).

The Service TIC attribution does not replace or remove the upstream authorship.
A identificação da Service TIC não substitui nem remove a autoria do projeto original.

This is an independent plugin, not an official GLPI core component.
Este é um plugin independente, não um componente oficial do núcleo do GLPI.
