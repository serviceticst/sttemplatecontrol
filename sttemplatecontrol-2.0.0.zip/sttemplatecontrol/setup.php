<?php

/**
 * SPDX-FileCopyrightText: 2026 Curtis Conard
 * SPDX-FileCopyrightText: 2026 Service TIC
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Service TIC fork based on Unstick ITIL Templates by Curtis Conard.
 * Product identity and localisation revision: 2026-10-08. See NOTICE.md.
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access this file directly");
}

/**
 * -------------------------------------------------------------------------
 * ST Template Control
 * -------------------------------------------------------------------------
 * Controls persistent template bindings in GLPI, allowing native template selection based on category, active profile, and entity.
 *
 * @copyright Copyright (C) 2026 Service TIC
 * @license   GPL-3.0-or-later
 * -------------------------------------------------------------------------
 */

use Glpi\Plugin\Hooks;

define('PLUGIN_STTEMPLATECONTROL_VERSION', '2.0.0');
define('PLUGIN_STTEMPLATECONTROL_MIN_GLPI', '11.0.0');
define('PLUGIN_STTEMPLATECONTROL_MAX_GLPI', '12.0.0');
define('PLUGIN_STTEMPLATECONTROL_MIN_PHP', '8.2.0');
define('PLUGIN_STTEMPLATECONTROL_I18N_DOMAIN', 'sttemplatecontrol');

require_once __DIR__ . '/inc/config.class.php';
require_once __DIR__ . '/inc/templatehandler.class.php';

/**
 * Initialize plugin hooks.
 */
function plugin_init_sttemplatecontrol(): void
{
    global $PLUGIN_HOOKS;

    $PLUGIN_HOOKS['csrf_compliant']['sttemplatecontrol'] = true;

    if (!Plugin::isPluginActive('sttemplatecontrol')) {
        return;
    }

    Plugin::registerClass(
        PluginSttemplatecontrolConfig::class,
        ['addtabon' => [Config::class]]
    );

    if (Session::haveRight('config', READ)) {
        $PLUGIN_HOOKS[Hooks::CONFIG_PAGE]['sttemplatecontrol'] = 'front/config.form.php';
    }

    // These hooks receive an array containing "item" and "options".
    $PLUGIN_HOOKS[Hooks::PRE_SHOW_ITEM]['sttemplatecontrol'] = [
        PluginSttemplatecontrolTemplateHandler::class,
        'preShowItem',
    ];

    // These hooks receive the item instance and can be scoped by item type.
    $supported_types = [Ticket::class, Change::class, Problem::class];

    foreach ($supported_types as $itemtype) {
        $PLUGIN_HOOKS[Hooks::POST_PREPAREADD]['sttemplatecontrol'][$itemtype] = [
            PluginSttemplatecontrolTemplateHandler::class,
            'postPrepareAdd',
        ];
        $PLUGIN_HOOKS[Hooks::PRE_ITEM_UPDATE]['sttemplatecontrol'][$itemtype] = [
            PluginSttemplatecontrolTemplateHandler::class,
            'preItemUpdate',
        ];
        $PLUGIN_HOOKS[Hooks::ITEM_UPDATE]['sttemplatecontrol'][$itemtype] = [
            PluginSttemplatecontrolTemplateHandler::class,
            'itemUpdate',
        ];
    }
}

/**
 * Plugin metadata.
 *
 * @return array<string, mixed>
 */
function plugin_version_sttemplatecontrol(): array
{
    return [
        'name'         => 'ST Template Control',
        'version'      => PLUGIN_STTEMPLATECONTROL_VERSION,
        'description'  => __('Controls persistent template bindings in GLPI, allowing native template selection based on category, active profile, and entity.', PLUGIN_STTEMPLATECONTROL_I18N_DOMAIN),
        'author'       => 'Service TIC (fork) / Curtis Conard',
        'license'      => 'GPLv3+',
        'homepage'     => 'https://www.servicetic.com.br',
        'requirements' => [
            'glpi' => [
                'min' => PLUGIN_STTEMPLATECONTROL_MIN_GLPI,
                'max' => PLUGIN_STTEMPLATECONTROL_MAX_GLPI,
            ],
            'php' => [
                'min' => PLUGIN_STTEMPLATECONTROL_MIN_PHP,
            ],
        ],
    ];
}

/**
 * Validate installation prerequisites.
 */
function plugin_sttemplatecontrol_check_prerequisites(): bool
{
    if (!defined('GLPI_VERSION')) {
        echo __('Unable to identify the GLPI version.', PLUGIN_STTEMPLATECONTROL_I18N_DOMAIN);
        return false;
    }

    if (version_compare(PHP_VERSION, PLUGIN_STTEMPLATECONTROL_MIN_PHP, '<')) {
        echo sprintf(
            __('ST Template Control requires PHP %s or later.', PLUGIN_STTEMPLATECONTROL_I18N_DOMAIN),
            PLUGIN_STTEMPLATECONTROL_MIN_PHP
        );
        return false;
    }

    if (version_compare(GLPI_VERSION, PLUGIN_STTEMPLATECONTROL_MIN_GLPI, '<')) {
        echo sprintf(
            __('ST Template Control requires GLPI %s or later.', PLUGIN_STTEMPLATECONTROL_I18N_DOMAIN),
            PLUGIN_STTEMPLATECONTROL_MIN_GLPI
        );
        return false;
    }

    if (version_compare(GLPI_VERSION, PLUGIN_STTEMPLATECONTROL_MAX_GLPI, '>=')) {
        echo sprintf(
            __('ST Template Control has not yet been validated with GLPI %s or later.', PLUGIN_STTEMPLATECONTROL_I18N_DOMAIN),
            PLUGIN_STTEMPLATECONTROL_MAX_GLPI
        );
        return false;
    }

    return true;
}

/**
 * The plugin is ready immediately after activation.
 */
function plugin_sttemplatecontrol_check_config(bool $verbose = false): bool
{
    return true;
}
