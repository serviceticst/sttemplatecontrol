<?php

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access this file directly");
}

/**
 * Install ST Template Control.
 */
function plugin_sttemplatecontrol_install(): bool
{
    $defaults = PluginSttemplatecontrolConfig::getDefaultConfig();
    $current  = Config::getConfigurationValues(PluginSttemplatecontrolConfig::CONTEXT);

    // Keep previously saved values while adding defaults introduced by upgrades.
    Config::setConfigurationValues(
        PluginSttemplatecontrolConfig::CONTEXT,
        array_replace($defaults, $current)
    );

    return true;
}

/**
 * Uninstall ST Template Control.
 */
function plugin_sttemplatecontrol_uninstall(): bool
{
    $config = new Config();
    $config->deleteByCriteria([
        'context' => PluginSttemplatecontrolConfig::CONTEXT,
    ]);

    return true;
}
