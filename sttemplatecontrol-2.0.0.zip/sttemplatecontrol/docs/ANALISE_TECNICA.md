# Análise técnica — ST Template Control 2.0.0

> Documento técnico herdado do pacote anterior, com nomes e caminhos atualizados. As verificações desta entrega e os limites dos testes estão em [REVISAO_2.0.0.md](REVISAO_2.0.0.md).

## Fase 1 — Resumo executivo

O comportamento observado no GLPI 11 não decorre de uma inversão simples da ordem `Categoria > Perfil > Entidade`. Essa ordem continua explícita no método `CommonITILObject::getITILTemplateToUse()`.

A mudança relevante é anterior à resolução: ao renderizar um item existente, o GLPI 11 lê o campo persistido (`tickettemplates_id`, `changetemplates_id` ou `problemtemplates_id`) e o envia ao resolvedor como `force_template`. Como o template forçado é a primeira opção do método, ele impede que categoria, perfil ou entidade sejam reavaliados para quem abre o item depois.

O GLPI 10 não utilizava o campo persistido do item como template forçado na exibição comum. Por isso, cada visualização recalculava o template pelo contexto corrente.

### Veredito

- Restaurar o comportamento do GLPI 10 via plugin: **SIM**.
- Reordenar de forma universal e arbitrária todas as fontes em todos os fluxos usando somente hooks públicos: **PARCIALMENTE**.
- Origem nativa “template diretamente no usuário”: **NÃO ENCONTRADA** no resolvedor do GLPI 10/11.

A lógica funcional originalmente introduzida na versão 1.0.0 e mantida na 2.0.0 implementa a alternativa segura e comprovável: **modo de compatibilidade GLPI 10**.

A versão 2.0.0 também acrescenta duas camadas exclusivamente de apresentação, sem impacto no resolvedor de templates:

- internacionalização gettext em `en_GB`, `en_US`, `pt_BR`, `es_ES` e `fr_FR`;
- painel institucional responsivo da Service TIC na aba de configuração, usando imagens locais e links HTTPS protegidos com `noopener noreferrer`.

---

## Fase 2 — GLPI 10

### Classe

`CommonITILObject`

### Arquivo

`src/CommonITILObject.php`

### Método de resolução

`getITILTemplateToUse($force_template, $type, $itilcategories_id, $entities_id)`

### Ordem interna

1. template forçado, quando fornecido explicitamente;
2. template da categoria e tipo;
3. template do perfil ativo;
4. template da entidade;
5. objeto de template vazio.

### Ponto decisivo no formulário

Na versão 10, `showForm()` chamava o resolvedor usando essencialmente:

```php
$options['template_preview'] ?? 0
```

Logo, em uma exibição normal de item existente, o ID persistido no item não era automaticamente promovido a template forçado.

---

## Fase 3 — GLPI 11

### Classe

`CommonITILObject`

### Arquivo

`src/CommonITILObject.php`

### Ordem interna

Permanece:

1. template forçado;
2. categoria;
3. perfil ativo;
4. entidade.

### Alteração em `showForm()`

O GLPI 11 calcula:

```php
$predefined_template = $this->fields[$template_class::getForeignKeyField()];
```

E chama:

```php
$this->getITILTemplateToUse(
    $options['template_preview'] ?? $predefined_template,
    ...
);
```

Consequência: o template salvo no item se torna `force_template` em visualizações posteriores.

### Persistência na criação

`prepareInputForAdd()` converte o campo de formulário legado, como `_tickettemplate`, no campo real de banco, como `tickettemplates_id`.

### Persistência na atualização

`prepareInputForUpdate()` e `handleTemplateFields()` podem recalcular e regravar o template quando categoria, entidade ou tipo mudam.

---

## Fase 4 — Diff conceitual GLPI 10 × GLPI 11

| Etapa | GLPI 10 | GLPI 11 |
|---|---|---|
| Criação/renderização | resolve pelo contexto | resolve pelo contexto |
| Persistência do ID do template no item | não domina a visualização posterior | ID é salvo no item |
| Abertura posterior | recalcula Categoria > Perfil > Entidade | usa primeiro o ID salvo como template forçado |
| Efeito | permissões/campos acompanham o contexto atual | permissões/campos podem ficar “presos” ao contexto da criação |

A mudança de precedência percebida é, portanto:

```text
GLPI 10:  preview explícito > categoria > perfil > entidade
GLPI 11:  preview explícito ou template persistido > categoria > perfil > entidade
```

---

## Fase 5 — Issue #25095

A issue descreve o efeito funcional do template “preso”: campos ocultos pelo template usado no self-service continuam ocultos quando um técnico ou administrador abre o chamado depois. Isso é coerente com o campo persistido ser reutilizado como template forçado.

Referência: https://github.com/glpi-project/glpi/issues/25095

---

## Fase 6 — `glpi-unsticktemplates-plugin`

O plugin de referência usa o hook `post_prepareadd` para remover o campo persistente do template do `input` antes do `INSERT`. A ideia central é correta e foi reutilizada:

- deixar os valores já aplicados pelo template no fluxo atual;
- impedir que o ID do template fique gravado e domine visualizações futuras.

A implementação ST amplia a cobertura:

- neutraliza também vínculos já existentes antes da exibição;
- trata Chamados, Mudanças e Problemas separadamente;
- trata regravação do campo em atualizações;
- oferece configuração e log.

Referência: https://github.com/cconard96/glpi-unsticktemplates-plugin

---

## Fase 7 — Viabilidade técnica

### É possível controlar a ordem de precedência via plugin?

**PARCIALMENTE.**

O hook `pre_show_item` permite alterar `options` e o item antes de `showForm()`, então é possível neutralizar o template persistido e até forçar um template calculado pelo plugin na interface padrão.

Porém, uma ordem arbitrária e universal teria limitações:

1. o resolvedor interno possui ordem codificada no core;
2. `getITILTemplateFromInput()` repete essa ordem nas atualizações;
3. não existe hook público depois de `prepareInputForUpdate()` e antes do `UPDATE`;
4. API, coletor, formulários nativos e chamadas diretas não necessariamente passam pela montagem da aba principal;
5. não existe fonte nativa direta “usuário” no resolvedor para ser ordenada;
6. copiar integralmente o resolvedor para o plugin aumentaria o risco de divergência em patches do GLPI.

### Solução escolhida

Restaurar o comportamento exato e verificável do GLPI 10, deixando a resolução nativa do core operar sem o template persistido.

---

## Fase 8 — Arquitetura

```text
sttemplatecontrol/
├── setup.php
├── hook.php
├── inc/
│   ├── config.class.php
│   └── templatehandler.class.php
├── front/
│   └── config.form.php
├── templates/
│   └── config.html.twig
├── pics/
│   ├── service_tic_logo.png
│   └── service_tic_qrcode.png
├── public/pics/
│   ├── service_tic_logo.png
│   └── service_tic_qrcode.png
├── locales/
│   ├── sttemplatecontrol.pot
│   ├── en_GB.po / en_GB.mo
│   ├── en_US.po / en_US.mo
│   ├── pt_BR.po / pt_BR.mo
│   ├── es_ES.po / es_ES.mo
│   └── fr_FR.po / fr_FR.mo
├── docs/
│   ├── ANALISE_TECNICA.md
│   ├── PLANO_TESTES.md
│   └── VALIDACAO.md
├── tests/
│   ├── config-harness.php
│   ├── harness.php
│   ├── identity-harness.php
│   ├── i18n-harness.py
│   ├── marketing-harness.py
│   └── static-check.sh
├── composer.json
├── README.md
├── CHANGELOG.md
└── LICENSE
```

### Responsabilidades

- `setup.php`: metadados, compatibilidade, registro dos hooks e da aba.
- `hook.php`: instalação e desinstalação das configurações nativas do GLPI.
- `config.class.php`: configuração global em `glpi_configs`, contexto `plugin:sttemplatecontrol`, mensagens gettext e URLs institucionais.
- `templatehandler.class.php`: neutralização da opção forçada na exibição, prevenção no `INSERT` e limpeza no `UPDATE`.
- `config.form.php`: redireciona o botão Configurar para a aba correta.
- `config.html.twig`: interface segura com CSRF nativo, grade responsiva e painel institucional da Service TIC.
- `locales/`: catálogos editáveis `.po`, compilados `.mo` e template `.pot`.
- `pics/` e `public/pics/`: logomarca e QR Code locais, sem chamada de imagem externa.
- `marketing-harness.py`: valida os ativos, os links seguros e a presença dos elementos responsivos.

---

## Fase 9 — Implementação

### Exibição

`pre_show_item` é chamado antes de `showForm()`. O plugin:

1. preserva qualquer `template_preview` explicitamente solicitado;
2. quando não existe pré-visualização explícita, define `options[template_preview] = 0`;
3. o `showForm()` deixa de usar o campo persistido como fallback;
4. o GLPI resolve Categoria > Perfil ativo > Entidade.

O objeto e o banco não são alterados apenas por abrir o item.

### Criação

`post_prepareadd` é chamado depois de `prepareInputForAdd()` e antes do `INSERT`. O plugin remove somente o campo persistente. O campo legado de formulário é mantido para não interromper rotinas internas do fluxo atual.

### Atualização

`pre_item_update` remove os campos de template recebidos. Se categoria, entidade ou tipo mudarem, o core ainda pode recalcular o template em `handleTemplateFields()`.

Como o GLPI 11 não oferece `post_prepareupdate`, o hook `item_update` pode limpar o campo imediatamente depois do `UPDATE`. Essa limpeza:

- é configurável;
- não chama novamente `CommonDBTM::update()`;
- evita recursão;
- remove o campo da lista de alterações exposta a rotinas posteriores;
- inclui o campo na blacklist de histórico durante o processamento.

---

## Camada de apresentação da versão 2.0.0

A inclusão do painel institucional não participa de nenhum hook de criação ou atualização de item ITIL. Os dados usados no Twig são montados apenas em `PluginSttemplatecontrolConfig::showForConfig()`.

O fluxo é:

```text
Configurar > Geral > ST Template Control
        ↓
showForConfig()
        ↓
URLs locais das imagens + URLs HTTPS institucionais
        ↓
Template Twig com escape automático
        ↓
Painel lateral em telas amplas / empilhado em telas menores
```

Propriedades de segurança e privacidade:

- não há JavaScript de terceiros;
- não há pixel ou mecanismo de rastreamento;
- não há requisição externa para carregar logo ou QR Code;
- os links usam `target="_blank"` e `rel="noopener noreferrer"`;
- textos alternativos e títulos são traduzidos pelo mesmo domínio gettext do plugin;
- o painel não grava dado adicional em `glpi_configs` nem em tabelas ITIL.

---

## Fase 10 — Instalação

1. extrair a pasta `sttemplatecontrol` em `plugins/`;
2. aplicar proprietário/permissões compatíveis com o servidor web;
3. acessar `Configurar > Plugins`;
4. instalar;
5. ativar;
6. acessar `Configurar > Geral > ST Template Control`;
7. manter o modo ativo e selecionar os tipos desejados.

---

## Fase 11 — Plano de testes

Consulte `docs/PLANO_TESTES.md`.

---

## Fase 12 — Riscos e limitações

1. `pre_show_item` cobre o fluxo padrão que chama `CommonGLPI::displayStandardTab()`. Uma extensão externa que invoque `showForm()` diretamente pode contornar esse hook.
2. A limpeza pós-update depende dos nomes dos campos de template expostos pelas classes nativas.
3. O método `getITILTemplateFromInput()` possui indicação de mudança de visibilidade no GLPI 12; por isso o plugin declara compatibilidade somente com GLPI 11.
4. O plugin não inventa um template diretamente no usuário. Caso outro plugin implemente essa fonte, será necessária integração específica.
5. O comportamento de pré-visualização explícita é preservado intencionalmente.
6. O pacote recebeu lint e testes comportamentais isolados, mas precisa ser homologado com a versão exata e os plugins presentes no ambiente de destino.
