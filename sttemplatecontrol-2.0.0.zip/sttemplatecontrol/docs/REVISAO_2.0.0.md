# Verificação / Verification — ST Template Control 2.0.0

**Data / Date:** 2026-10-08  
**Autores / Authors:** Service TIC (fork) / Curtis Conard

## Português (Brasil)

### Alterações desta entrega

O pacote foi renomeado para **ST Template Control**, com versão **2.0.0**.
A descrição foi atualizada nos metadados PHP, no Composer, na tela de configuração,
nos READMEs em inglês e português e no texto para LinkedIn.

> Controla a vinculação persistente dos modelos no GLPI, permitindo a seleção nativa conforme a categoria, o perfil ativo e a entidade.

A identidade interna também passou a `sttemplatecontrol`: pasta, classes, constantes,
funções de inicialização e instalação, registro dos hooks, domínio gettext, namespace
Twig, contexto de configuração, caminhos das imagens e nome do arquivo de log.
As 25 mensagens dos cinco catálogos foram compiladas para arquivos `.mo`.

O crédito informado nos metadados é **Service TIC (fork) / Curtis Conard**.
O rodapé institucional, as imagens locais e o texto integral da licença foram preservados.
A lógica de tratamento dos modelos e os valores padrão das opções não foram alterados;
o contexto que armazena essas opções tem o novo nome.

### Substituição do pacote anterior

A nova identidade é instalada separadamente de `sttemplatepriority`. Faça backup,
registre as opções antigas e desative o plugin anterior antes de ativar o novo.
Instale a pasta completa `sttemplatecontrol` deste ZIP; não renomeie apenas a pasta antiga.
As configurações antigas não são migradas automaticamente nem apagadas pelo novo plugin.
Revise e salve as seis opções antes de testar criação ou atualização de registros.

A renomeação não cria tabelas, não altera o esquema do banco e não executa migração
em massa de chamados, mudanças, problemas ou vínculos de modelos. Não reativa nem
reconstrói vínculos de modelos que já tenham sido limpos pelo plugin anterior.

### Verificações executadas

Consulte [TEST_RESULTS_2.0.0.txt](TEST_RESULTS_2.0.0.txt) para a saída da execução local.
A suíte inclui sintaxe PHP, sete cenários isolados de tratamento de modelos, configuração
e cache, identidade e metadados, registro dos hooks, parâmetros da tela, isolamento dos
contextos na instalação/desinstalação, catálogos de tradução e ativos institucionais.

A conferência dos idiomas verifica as chaves compiladas, a equivalência PO/MO, os
marcadores de formatação, a versão do projeto e o domínio gettext. O nome do produto
não é traduzido; a descrição e as mensagens acompanham o idioma do usuário.

A comparação com o pacote anterior verificou que `inc/templatehandler.class.php`,
`hook.php` e `front/config.form.php` diferem apenas pela troca dos identificadores
relacionados ao nome. Em `inc/config.class.php`, além da renomeação, foi adicionada
somente a nova mensagem de descrição. A tela Twig recebeu a descrição e a renomeação
de seus identificadores, sem alterar os controles existentes.

**Limites:** os testes usam classes simuladas. Não houve instalação em uma instância
real do GLPI, teste em navegador, acesso a banco de produção, auditoria de segurança
completa nem teste de desempenho. A faixa GLPI `>= 11.0.0` e `< 12.0.0` continua sendo
compatibilidade declarada, não homologação de todas as versões 11.x.

### Publicação

Coloque o conteúdo da pasta `sttemplatecontrol` na raiz do seu fork. Para instalar no
GLPI, mantenha a pasta `plugins/sttemplatecontrol/`. O ZIP já possui a pasta superior
correta. Troque `[INSERIR LINK DO FORK]` em `LINKEDIN.pt-BR.txt` pelo endereço real antes
de publicar. Nenhum repositório, commit, release ou postagem externa foi criado.

## English

### Scope

The package is now **ST Template Control 2.0.0**, with authors recorded as
**Service TIC (fork) / Curtis Conard** and this description:

> Controls persistent template bindings in GLPI, allowing native template selection based on category, active profile, and entity.

The internal identity is `sttemplatecontrol` throughout the directory, classes,
constants, hooks, gettext domain, Twig namespace, configuration context, asset paths
and log name. Documentation, five translation catalogues and the LinkedIn draft have
been updated. The licence and institutional assets are unchanged. Template-handling
logic and configuration defaults are retained.

### Replacing the previous identity

Deactivate `sttemplatepriority` before enabling this package and retain a backup of
the prior settings. Install the complete new directory. Old settings are not migrated
automatically or deleted; review all six options in the new plugin before testing
record creation or updates. Do not merely rename the old directory or run both plugins.
The rename does not restore previously cleared template links or perform bulk migration.

### Verification and limits

The local suite covers PHP syntax, seven isolated behaviour scenarios, configuration
and caching, identity metadata, hook registration, configuration view parameters,
separate installation/uninstallation contexts, all five catalogues (25 messages each)
and local branding assets. The recorded run is in `TEST_RESULTS_2.0.0.txt`.

Normalising the renamed identifiers confirms that the template handler, install/uninstall
hooks and configuration redirect match the previous implementation. The configuration
class adds only the description message beyond identifier renaming; the Twig template
adds the description without changing the existing controls. Licence and images were
compared byte for byte.

**No real GLPI instance, browser integration test or production database was used.**
The suite uses test doubles. No full security audit or performance benchmark was
performed. The declared GLPI range is not certification of every GLPI 11 release.

Place the contents of `sttemplatecontrol` at the repository root. The distribution ZIP
contains the required top-level plugin directory. The LinkedIn draft still contains
`[INSERIR LINK DO FORK]`; replace it before posting. No external account was modified.
