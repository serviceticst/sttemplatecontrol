# Plano de testes — ST Template Control 2.0.0

## Preparação

Crie templates de chamado facilmente distinguíveis:

- `TPL-CATEGORIA`: oculta um campo e predefine o título;
- `TPL-PERFIL`: torna um campo obrigatório e predefine outro valor;
- `TPL-ENTIDADE`: usa uma terceira combinação.

Configure:

- uma categoria com `TPL-CATEGORIA`;
- o perfil ativo com `TPL-PERFIL`;
- a entidade com `TPL-ENTIDADE`;
- log de depuração temporariamente ativo.

## Matriz mínima

### Cenário 1 — Categoria possui template

Prioridade efetiva: Categoria > Perfil > Entidade.

Resultado esperado: `TPL-CATEGORIA`.

### Cenário 2 — Categoria sem template, perfil com template

Resultado esperado: `TPL-PERFIL`.

### Cenário 3 — Categoria e perfil sem template, entidade com template

Resultado esperado: `TPL-ENTIDADE`.

### Cenário 4 — Nenhuma origem possui template

Resultado esperado: formulário sem template ITIL carregado.

### Cenário 5 — Item antigo possui `tickettemplates_id`

1. identifique um chamado criado antes da ativação;
2. confirme no banco que possui `tickettemplates_id > 0`;
3. abra com um perfil cujo template é diferente.

Resultado esperado: o valor persistido é ignorado na exibição e o template do contexto atual é aplicado.

### Cenário 6 — Nova criação

1. crie um chamado com template aplicado;
2. consulte `glpi_tickets.tickettemplates_id`.

Resultado esperado: valor `0` após a criação.

### Cenário 7 — Mudança de categoria em chamado existente

1. altere para uma categoria com outro template;
2. salve;
3. reabra o chamado;
4. consulte `tickettemplates_id`.

Resultado esperado:

- validações do novo template são respeitadas durante a alteração;
- com a opção de limpeza ativa, `tickettemplates_id = 0` após salvar;
- na reabertura, o template é recalculado.

### Cenário 8 — Pré-visualização explícita

Abra um template pela função nativa de pré-visualização.

Resultado esperado: o template selecionado explicitamente é preservado.

## Interfaces e canais

Execute os cenários aplicáveis em:

- interface central;
- interface simplificada/self-service;
- criação por técnico em nome de requerente;
- API REST;
- coletor de e-mail;
- formulários nativos do GLPI 11;
- criação por regra/automação usada no ambiente.

Observação: os canais sem renderização de formulário devem ser avaliados principalmente quanto à persistência do campo. Campos visuais ocultos/obrigatórios pertencem ao fluxo de interface.

## Perfis e entidades

- usuário com mais de um perfil;
- troca de perfil ativo;
- troca de entidade ativa;
- entidade filha herdando configuração;
- usuário sem acesso à entidade do item;
- técnico e requerente com templates de perfil distintos.

## Mudanças e problemas

Repita os cenários 2, 5, 6 e 7 para:

- `glpi_changes.changetemplates_id`;
- `glpi_problems.problemtemplates_id`.

## Regressão

Verifique:

- criação e atualização sem erro PHP;
- notificações não duplicadas;
- regras de negócio continuam executando;
- SLA/TTO/TTR não são alterados pelo plugin;
- histórico de categoria permanece normal;
- campos obrigatórios de categoria continuam bloqueando o salvamento;
- desativar o plugin restaura integralmente o comportamento padrão do GLPI 11.

## Segurança

- usuário sem direito `config` não altera opções;
- POST sem token CSRF é rejeitado pelo GLPI;
- acesso direto à página de configuração exige login e direito de leitura;
- valores de configuração são limitados aos campos apresentados pelo formulário nativo.

## Performance

Com log desativado, compare o tempo de abertura antes/depois. O plugin não faz consulta adicional para resolver templates: ele apenas lê as configurações do contexto e deixa o método nativo do GLPI executar.

## Evidências a coletar

- print da aba de configuração;
- IDs e nomes dos templates;
- perfil/entidade ativa em cada teste;
- valor do campo de template antes/depois;
- trecho de `files/_log/sttemplatecontrol.log` quando necessário;
- erro de PHP/SQL, caso exista.

## Internacionalização — versão 2.0.0

### Cenário I18N-1 — Português (Brasil)

1. Definir o idioma do usuário como `pt_BR`.
2. Abrir **Configurar > Geral > ST Template Control**.
3. Confirmar que títulos, alertas, opções, dica de log, botão de salvar e mensagem de somente leitura aparecem em português.

Resultado esperado: nenhuma string configurável do plugin aparece em inglês por falta de catálogo.

### Cenário I18N-2 — English (UK)

1. Definir o idioma como `en_GB`.
2. Abrir a configuração do plugin.

Resultado esperado: interface em inglês britânico; a descrição utiliza a grafia `behaviour`.

### Cenário I18N-3 — English (US)

1. Definir o idioma como `en_US`.
2. Abrir a configuração do plugin.

Resultado esperado: interface em inglês americano; a descrição utiliza a grafia `behavior`.

### Cenário I18N-4 — Español

1. Definir o idioma como `es_ES`.
2. Abrir a configuração do plugin.

Resultado esperado: interface traduzida para espanhol.

### Cenário I18N-5 — Français

1. Definir o idioma como `fr_FR`.
2. Abrir a configuração do plugin.

Resultado esperado: interface traduzida para francês.

### Cenário I18N-6 — Troca de idioma

1. Acessar a tela do plugin em `pt_BR`.
2. Alterar o idioma do usuário para outro locale suportado.
3. Encerrar e iniciar a sessão novamente, se necessário.
4. Reabrir a configuração.

Resultado esperado: o plugin acompanha o locale ativo do GLPI sem alterar sua configuração funcional.

### Cenário I18N-7 — Catálogos compilados

Executar:

```bash
python3 tests/i18n-harness.py
```

Resultado esperado:

```text
[OK] 5 locales and 25 messages validated
```

## Painel institucional Service TIC — versão 2.0.0

### Cenário MKT-1 — Exibição em tela ampla

1. Abrir **Configurar > Geral > ST Template Control** em resolução igual ou superior a 1200 px.
2. Confirmar que o formulário permanece no bloco principal.
3. Confirmar que o painel Service TIC aparece à direita, sem sobrepor alertas ou campos.

Resultado esperado: grade com formulário e painel lateral alinhados pelo topo.

### Cenário MKT-2 — Exibição responsiva

1. Reduzir a largura da janela para menos de 1200 px.
2. Reabrir ou redimensionar a aba.

Resultado esperado: o painel é reposicionado abaixo do formulário, com largura máxima controlada e sem barra de rolagem horizontal.

### Cenário MKT-3 — Logomarca e QR Code

1. Confirmar que a logomarca é carregada.
2. Confirmar que o QR Code é carregado.
3. Confirmar no navegador que as imagens vêm de `/plugins/sttemplatecontrol/pics/`.

Resultado esperado: nenhum ativo visual é carregado de domínio externo.

### Cenário MKT-4 — Links externos

1. Clicar na logomarca ou no endereço do site.
2. Confirmar abertura de `https://www.servicetic.com.br` em nova guia.
3. Clicar no QR Code.
4. Confirmar abertura de `https://servicetic.com.br/links` em nova guia.
5. Inspecionar os links no navegador.

Resultado esperado: todos possuem `target="_blank"` e `rel="noopener noreferrer"`.

### Cenário MKT-5 — Tradução do painel

Repetir a abertura da tela em `pt_BR`, `en_GB`, `en_US`, `es_ES` e `fr_FR`.

Resultado esperado: “Desenvolvido por” e os atributos de acessibilidade acompanham o idioma ativo do GLPI; a marca e os endereços permanecem inalterados.

### Cenário MKT-6 — Ausência de impacto funcional

1. Alterar apenas o idioma do usuário.
2. Abrir e fechar a aba de configuração sem salvar.
3. Criar ou editar um chamado de teste.

Resultado esperado: o painel não grava configuração adicional, não gera chamada de API externa e não altera o resultado funcional do resolvedor de templates.

### Cenário MKT-7 — Validação automatizada

Executar:

```bash
python3 tests/marketing-harness.py
```

Resultado esperado:

```text
[OK] Service TIC marketing panel, secure links and mirrored PNG assets validated
```

