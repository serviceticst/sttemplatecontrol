# Validação do pacote — ST Template Control 2.0.0

## Escopo

A validação incluída no pacote cobre verificações estáticas e testes isolados da lógica do plugin. Ela não substitui a homologação dentro de uma instância real do GLPI 11 com banco de dados, demais plugins, regras, formulários, API e coletor.

## Verificações incluídas

O comando abaixo executa a suíte local:

```bash
bash tests/static-check.sh
```

Ele valida:

1. sintaxe de todos os arquivos PHP com `php -l`;
2. presença dos arquivos obrigatórios do plugin;
3. comportamento isolado de neutralização de `template_preview`;
4. preservação de pré-visualização explícita;
5. remoção da FK de template durante criação;
6. tratamento do campo de template durante atualização;
7. limpeza controlada da FK persistida após atualização;
8. configurações por tipo de item;
9. sanitização dos valores de configuração;
10. cache de configuração durante a requisição;
11. presença dos catálogos `en_GB`, `en_US`, `pt_BR`, `es_ES` e `fr_FR`;
12. leitura dos arquivos GNU gettext `.mo` compilados;
13. cobertura de todas as strings traduzíveis do plugin;
14. preservação de placeholders `sprintf` entre mensagem-fonte e tradução;
15. distinção de grafia britânica `behaviour` e americana `behavior`;
16. presença das 25 mensagens traduzíveis esperadas;
17. existência e assinatura PNG da logomarca e do QR Code;
18. dimensões mínimas dos ativos visuais;
19. igualdade dos arquivos em `pics/` e `public/pics/`;
20. presença da grade responsiva do painel institucional;
21. utilização de links HTTPS em nova guia;
22. proteção `rel="noopener noreferrer"` em todos os links externos;
23. ausência de carregamento remoto das imagens do painel.

24. nome, versão, autores, descrição e identidade interna do plugin;
25. registro dos hooks, renderização simulada da configuração e isolamento entre os contextos antigo e novo.

## Internacionalização

A versão 2.0.0 adota o padrão gettext do GLPI:

- idioma-fonte: inglês britânico (`en_GB`);
- domínio gettext: `sttemplatecontrol`;
- template de tradução: `locales/sttemplatecontrol.pot`;
- catálogos editáveis: `locales/*.po`;
- catálogos compilados: `locales/*.mo`;
- mensagens da interface principal e do painel institucional traduzidas no mesmo domínio.

## Homologação recomendada

Antes de produção, validar no GLPI 11 pelo menos:

- usuário com idioma `pt_BR`;
- usuário com idioma `en_GB`;
- usuário com idioma `en_US`;
- usuário com idioma `es_ES`;
- usuário com idioma `fr_FR`;
- troca de idioma e novo login/sessão;
- tela Setup > General > ST Template Control;
- painel Service TIC à direita em tela ampla e abaixo do formulário em tela reduzida;
- carregamento local da logomarca e do QR Code;
- links do site e do QR Code em nova guia com `noopener noreferrer`;
- criação e edição de Ticket, Change e Problem;
- categoria com e sem template;
- perfil ativo com template;
- entidade com template;
- pré-visualização explícita de template;
- criação pela interface central e simplificada;
- API REST, coletor e formulários utilizados no ambiente.

## Limite da validação

Os testes do pacote usam harnesses isolados e não carregam todo o kernel do GLPI. Portanto, a validação final deve ser feita em ambiente de homologação usando a mesma versão do GLPI, PHP, banco e plugins da produção.
