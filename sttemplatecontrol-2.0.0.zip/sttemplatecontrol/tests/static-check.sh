#!/usr/bin/env bash
set -euo pipefail

PLUGIN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

find "$PLUGIN_DIR" -type f -name '*.php' -print0 \
  | while IFS= read -r -d '' file; do
      php -l "$file"
    done

required=(
  setup.php
  hook.php
  inc/config.class.php
  inc/templatehandler.class.php
  front/config.form.php
  templates/config.html.twig
  pics/service_tic_logo.png
  pics/service_tic_qrcode.png
  public/pics/service_tic_logo.png
  public/pics/service_tic_qrcode.png
  locales/sttemplatecontrol.pot
  locales/en_GB.po
  locales/en_GB.mo
  locales/en_US.po
  locales/en_US.mo
  locales/pt_BR.po
  locales/pt_BR.mo
  locales/es_ES.po
  locales/es_ES.mo
  locales/fr_FR.po
  locales/fr_FR.mo
  tests/harness.php
  tests/config-harness.php
  tests/identity-harness.php
  tests/i18n-harness.py
  tests/marketing-harness.py
  docs/VALIDACAO.md
  README.md
  README.pt-BR.md
  NOTICE.md
  LICENSE
)

for path in "${required[@]}"; do
  test -f "$PLUGIN_DIR/$path" || {
    echo "Required file missing: $path" >&2
    exit 1
  }
done

php "$PLUGIN_DIR/tests/harness.php"
php "$PLUGIN_DIR/tests/config-harness.php"
php "$PLUGIN_DIR/tests/identity-harness.php"
python3 "$PLUGIN_DIR/tests/i18n-harness.py"
python3 "$PLUGIN_DIR/tests/marketing-harness.py"

echo "Static, behavioural, translation and marketing validation completed."
