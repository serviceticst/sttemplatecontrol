<?php

declare(strict_types=1);

define('GLPI_ROOT', dirname(__DIR__, 3));

/**
 * Isolated behavior tests for ST Template Control.
 *
 * These stubs model only the public state used by the plugin handler. They do
 * not replace functional tests inside a real GLPI 11 installation.
 */

final class PluginSttemplatecontrolConfig
{
    /** @var array<string, int> */
    public static array $config = [
        'enabled'                  => 1,
        'apply_ticket'             => 1,
        'apply_change'             => 1,
        'apply_problem'            => 1,
        'clear_template_on_update' => 1,
        'debug'                    => 0,
    ];

    /** @return array<string, int> */
    public static function getConfig(): array
    {
        return self::$config;
    }
}

class CommonITILObject
{
    /** @var array<string, mixed> */
    public array $fields = [];

    /** @var array<string, mixed>|false */
    public array|false $input = [];

    /** @var list<string> */
    public array $history_blacklist = [];

    /** @var array<string, mixed> */
    public array $oldvalues = [];

    /** @var list<string> */
    public array $updates = [];

    public function __construct(int $id = 0, array $fields = [])
    {
        $this->fields = array_replace(['id' => $id], $fields);
    }

    public function getID(): int
    {
        return (int) ($this->fields['id'] ?? 0);
    }

    public function getType(): string
    {
        return static::class;
    }

    public static function getTable(): string
    {
        return 'glpi_stub';
    }

    public static function getIndexName(): string
    {
        return 'id';
    }

    public static function getTemplateClass(): string
    {
        return StubTemplate::class;
    }

    public static function getTemplateFormFieldName(): string
    {
        return '_stubtemplate';
    }
}

final class Ticket extends CommonITILObject
{
    public static function getTable(): string
    {
        return 'glpi_tickets';
    }

    public static function getTemplateClass(): string
    {
        return TicketTemplate::class;
    }

    public static function getTemplateFormFieldName(): string
    {
        return '_tickettemplate';
    }
}

final class Change extends CommonITILObject
{
    public static function getTable(): string
    {
        return 'glpi_changes';
    }

    public static function getTemplateClass(): string
    {
        return ChangeTemplate::class;
    }

    public static function getTemplateFormFieldName(): string
    {
        return '_changetemplate';
    }
}

final class Problem extends CommonITILObject
{
    public static function getTable(): string
    {
        return 'glpi_problems';
    }

    public static function getTemplateClass(): string
    {
        return ProblemTemplate::class;
    }

    public static function getTemplateFormFieldName(): string
    {
        return '_problemtemplate';
    }
}

class StubTemplate
{
    public static function getForeignKeyField(): string
    {
        return 'stubtemplates_id';
    }
}

final class TicketTemplate extends StubTemplate
{
    public static function getForeignKeyField(): string
    {
        return 'tickettemplates_id';
    }
}

final class ChangeTemplate extends StubTemplate
{
    public static function getForeignKeyField(): string
    {
        return 'changetemplates_id';
    }
}

final class ProblemTemplate extends StubTemplate
{
    public static function getForeignKeyField(): string
    {
        return 'problemtemplates_id';
    }
}

final class Toolbox
{
    /** @var list<array{file: string, message: string}> */
    public static array $logs = [];

    public static function logInFile(string $file, string $message): void
    {
        self::$logs[] = ['file' => $file, 'message' => $message];
    }
}

final class StubDB
{
    /** @var list<array{table: string, values: array<string, mixed>, where: array<string, mixed>}> */
    public array $updates = [];

    public bool $fieldExistsResult = true;
    public bool $updateResult = true;

    public function fieldExists(string $table, string $field): bool
    {
        return $this->fieldExistsResult;
    }

    /**
     * @param array<string, mixed> $values
     * @param array<string, mixed> $where
     */
    public function update(string $table, array $values, array $where): bool
    {
        $this->updates[] = compact('table', 'values', 'where');
        return $this->updateResult;
    }
}

require_once dirname(__DIR__) . '/inc/templatehandler.class.php';

/** @throws RuntimeException */
function assertSameValue(mixed $expected, mixed $actual, string $message): void
{
    if ($expected !== $actual) {
        throw new RuntimeException(
            $message . sprintf(
                "\nEsperado: %s\nObtido: %s",
                var_export($expected, true),
                var_export($actual, true)
            )
        );
    }
}

/** @throws RuntimeException */
function assertTrueValue(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

function resetConfig(): void
{
    PluginSttemplatecontrolConfig::$config = [
        'enabled'                  => 1,
        'apply_ticket'             => 1,
        'apply_change'             => 1,
        'apply_problem'            => 1,
        'clear_template_on_update' => 1,
        'debug'                    => 0,
    ];
}

$tests = [];

$tests['pre_show define zero through nested reference'] = static function (): void {
    resetConfig();
    $ticket = new Ticket(100, ['tickettemplates_id' => 77]);
    $options = [];
    $payload = ['item' => $ticket, 'options' => &$options];

    PluginSttemplatecontrolTemplateHandler::preShowItem($payload);

    assertTrueValue(array_key_exists('template_preview', $options), 'template_preview não foi definido.');
    assertSameValue(0, $options['template_preview'], 'O vínculo persistido deveria ser neutralizado.');
    assertSameValue(77, $ticket->fields['tickettemplates_id'], 'A exibição não deve mutar o objeto.');
};

$tests['explicit preview is preserved'] = static function (): void {
    resetConfig();
    $ticket = new Ticket(100, ['tickettemplates_id' => 77]);
    $options = ['template_preview' => 31];
    $payload = ['item' => $ticket, 'options' => &$options];

    PluginSttemplatecontrolTemplateHandler::preShowItem($payload);

    assertSameValue(31, $options['template_preview'], 'A pré-visualização explícita deve ser preservada.');
};

$tests['post prepare add removes only persistent field'] = static function (): void {
    resetConfig();
    $ticket = new Ticket();
    $ticket->input = [
        'name'               => 'Teste',
        '_tickettemplate'    => 42,
        'tickettemplates_id' => 42,
    ];

    PluginSttemplatecontrolTemplateHandler::postPrepareAdd($ticket);

    assertTrueValue(!array_key_exists('tickettemplates_id', $ticket->input), 'Campo persistente não foi removido.');
    assertSameValue(42, $ticket->input['_tickettemplate'], 'Campo legado do fluxo atual deve permanecer.');
    assertSameValue('Teste', $ticket->input['name'], 'Campos não relacionados não podem ser alterados.');
};

$tests['pre update removes template inputs and blacklists history'] = static function (): void {
    resetConfig();
    $ticket = new Ticket(9, ['tickettemplates_id' => 42]);
    $ticket->input = [
        'id'                 => 9,
        'name'               => 'Alterado',
        '_tickettemplate'    => 42,
        'tickettemplates_id' => 42,
    ];

    PluginSttemplatecontrolTemplateHandler::preItemUpdate($ticket);

    assertTrueValue(!array_key_exists('tickettemplates_id', $ticket->input), 'FK não removida do input de atualização.');
    assertTrueValue(!array_key_exists('_tickettemplate', $ticket->input), 'Campo de formulário não removido.');
    assertSameValue('Alterado', $ticket->input['name'], 'Campo de negócio não relacionado foi alterado.');
    assertTrueValue(in_array('tickettemplates_id', $ticket->history_blacklist, true), 'FK não foi adicionada à blacklist de histórico.');
};

$tests['post update clears persisted field without recursion'] = static function (): void {
    resetConfig();
    global $DB;
    $DB = new StubDB();

    $ticket = new Ticket(15, ['tickettemplates_id' => 42]);
    $ticket->input = ['tickettemplates_id' => 42, 'name' => 'Alterado'];
    $ticket->oldvalues = ['tickettemplates_id' => 12, 'name' => 'Anterior'];
    $ticket->updates = ['name', 'tickettemplates_id'];

    PluginSttemplatecontrolTemplateHandler::itemUpdate($ticket);

    assertSameValue(1, count($DB->updates), 'A limpeza deveria executar exatamente um UPDATE direto.');
    assertSameValue('glpi_tickets', $DB->updates[0]['table'], 'Tabela incorreta.');
    assertSameValue(['tickettemplates_id' => 0], $DB->updates[0]['values'], 'Valor de limpeza incorreto.');
    assertSameValue(['id' => 15], $DB->updates[0]['where'], 'Critério de limpeza incorreto.');
    assertSameValue(0, $ticket->fields['tickettemplates_id'], 'Estado em memória não foi sincronizado.');
    assertTrueValue(!in_array('tickettemplates_id', $ticket->updates, true), 'FK permaneceu na lista de atualizações.');
    assertTrueValue(!array_key_exists('tickettemplates_id', $ticket->oldvalues), 'FK permaneceu nos valores antigos.');
};

$tests['disabled type is untouched'] = static function (): void {
    resetConfig();
    PluginSttemplatecontrolConfig::$config['apply_change'] = 0;
    $change = new Change(8, ['changetemplates_id' => 14]);
    $options = [];
    $payload = ['item' => $change, 'options' => &$options];

    PluginSttemplatecontrolTemplateHandler::preShowItem($payload);

    assertTrueValue(!array_key_exists('template_preview', $options), 'Tipo desativado não deveria ser alterado.');
};

$tests['cleanup option can be disabled'] = static function (): void {
    resetConfig();
    PluginSttemplatecontrolConfig::$config['clear_template_on_update'] = 0;
    global $DB;
    $DB = new StubDB();

    $problem = new Problem(5, ['problemtemplates_id' => 9]);
    PluginSttemplatecontrolTemplateHandler::itemUpdate($problem);

    assertSameValue(0, count($DB->updates), 'A limpeza foi executada apesar de desativada.');
};

$passed = 0;
foreach ($tests as $name => $test) {
    $test();
    ++$passed;
    echo "[OK] {$name}\n";
}

echo sprintf("Todos os %d testes isolados passaram.\n", $passed);
