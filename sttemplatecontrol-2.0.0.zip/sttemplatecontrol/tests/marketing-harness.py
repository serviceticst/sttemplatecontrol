#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import struct
from pathlib import Path

PLUGIN_DIR = Path(__file__).resolve().parent.parent
TEMPLATE = PLUGIN_DIR / 'templates' / 'config.html.twig'
CONFIG = PLUGIN_DIR / 'inc' / 'config.class.php'
SETUP = PLUGIN_DIR / 'setup.php'


def fail(message: str) -> None:
    raise RuntimeError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open('rb') as fh:
        header = fh.read(24)

    if len(header) != 24 or header[:8] != b'\x89PNG\r\n\x1a\n':
        fail(f'Invalid PNG signature: {path.relative_to(PLUGIN_DIR)}')

    if header[12:16] != b'IHDR':
        fail(f'Missing PNG IHDR chunk: {path.relative_to(PLUGIN_DIR)}')

    return struct.unpack('>II', header[16:24])


template = TEMPLATE.read_text(encoding='utf-8')
config = CONFIG.read_text(encoding='utf-8')
setup = SETUP.read_text(encoding='utf-8')

required_template_fragments = [
    'sttemplatecontrol-config-grid',
    'grid-template-columns: minmax(0, 1fr) 270px',
    '@media (max-width: 1199.98px)',
    'sttemplatecontrol-marketing-card',
    'marketing.website_url',
    'marketing.links_url',
    'marketing.logo_url',
    'marketing.qrcode_url',
    'i18n.developed_by',
    'i18n.website_link_title',
    'i18n.links_link_title',
    'i18n.logo_alt',
    'i18n.qrcode_alt',
    'loading="lazy"',
]

for fragment in required_template_fragments:
    if fragment not in template:
        fail(f'Missing marketing template fragment: {fragment}')

if template.count('target="_blank"') < 3:
    fail('Every external marketing link must open in a new tab')

if template.count('rel="noopener noreferrer"') < 3:
    fail('Every external marketing link must use noopener noreferrer')

required_config_fragments = [
    "'developed_by' => __('Developed by:'",
    "'website_link_title' => __('Visit the Service TIC website'",
    "'links_link_title' => __('Open Service TIC links'",
    "'logo_alt' => __('Service TIC logo'",
    "'qrcode_alt' => __('QR code for Service TIC links'",
    "'/plugins/sttemplatecontrol/pics'",
    "'https://www.servicetic.com.br'",
    "'https://servicetic.com.br/links'",
]

for fragment in required_config_fragments:
    if fragment not in config:
        fail(f'Missing marketing configuration fragment: {fragment}')

if "'homepage'     => 'https://www.servicetic.com.br'" not in setup:
    fail('Plugin homepage metadata does not point to Service TIC')

assets = {
    'service_tic_logo.png': (500, 500),
    'service_tic_qrcode.png': (100, 100),
}

for filename, minimum in assets.items():
    normal = PLUGIN_DIR / 'pics' / filename
    public = PLUGIN_DIR / 'public' / 'pics' / filename

    if not normal.is_file():
        fail(f'Missing marketing asset: {normal.relative_to(PLUGIN_DIR)}')
    if not public.is_file():
        fail(f'Missing public marketing asset: {public.relative_to(PLUGIN_DIR)}')

    normal_dimensions = png_dimensions(normal)
    public_dimensions = png_dimensions(public)

    if normal_dimensions[0] < minimum[0] or normal_dimensions[1] < minimum[1]:
        fail(
            f'Unexpectedly small asset {filename}: '
            f'{normal_dimensions[0]}x{normal_dimensions[1]}'
        )

    if normal_dimensions != public_dimensions:
        fail(f'Asset dimensions differ between pics/ and public/pics/: {filename}')

    if sha256(normal) != sha256(public):
        fail(f'Asset contents differ between pics/ and public/pics/: {filename}')

print('[OK] Service TIC marketing panel, secure links and mirrored PNG assets validated')
