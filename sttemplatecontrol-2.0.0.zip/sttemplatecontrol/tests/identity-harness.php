<?php

/**
 * Isolated plugin identity and lifecycle checks. No live GLPI is loaded.
 */
declare(strict_types=1);

namespace Glpi\Plugin {
    final class Hooks
    {
        public const CONFIG_PAGE = 'config_page';
        public const PRE_SHOW_ITEM = 'pre_show_item';
        public const POST_PREPAREADD = 'post_prepareadd';
        public const PRE_ITEM_UPDATE = 'pre_item_update';
        public const ITEM_UPDATE = 'item_update';
    }
}

namespace Glpi\Application\View {
    final class TemplateRenderer
    {
        public static string $template = '';
        public static array $parameters = [];
        public static int $renders = 0;

        public static function getInstance(): self
        {
            return new self();
        }

        public function display(string $template, array $parameters = []): void
        {
            self::$template = $template;
            self::$parameters = $parameters;
            ++self::$renders;
        }
    }
}

namespace {
    use Glpi\Application\View\TemplateRenderer;
    use Glpi\Plugin\Hooks;

    define('GLPI_ROOT', dirname(__DIR__, 3));
    define('GLPI_VERSION', '11.0.0'); // Prerequisite fixture, not an installed GLPI.
    const READ = 1;
    const UPDATE = 2;

    class CommonGLPI
    {
        public static function createTabEntry(string $label, int $count = 0, ?string $class = null): string
        {
            return $label;
        }
    }

    class Config extends CommonGLPI
    {
        public static array $contexts = [];

        public static function getConfigurationValues(string $context): array
        {
            return self::$contexts[$context] ?? [];
        }

        public static function setConfigurationValues(string $context, array $values): void
        {
            self::$contexts[$context] = $values;
        }

        public function deleteByCriteria(array $criteria): bool
        {
            unset(self::$contexts[$criteria['context']]);
            return true;
        }
    }

    final class Session
    {
        public static bool $read = true;
        public static bool $update = true;

        public static function haveRight(string $right, int $level): bool
        {
            return $right === 'config' && ($level === READ ? self::$read : self::$update);
        }
    }

    final class Plugin
    {
        public static bool $active = true;
        public static array $classes = [];

        public static function isPluginActive(string $name): bool
        {
            return $name === 'sttemplatecontrol' && self::$active;
        }

        public static function registerClass(string $class, array $options): void
        {
            self::$classes[$class] = $options;
        }
    }

    class CommonITILObject extends CommonGLPI {}
    class Ticket extends CommonITILObject {}
    class Change extends CommonITILObject {}
    class Problem extends CommonITILObject {}

    function __(string $message, string $domain = ''): string
    {
        if ($domain !== 'sttemplatecontrol') {
            throw new \RuntimeException('Unexpected translation domain: ' . $domain);
        }
        return $message;
    }

    function assertIdentity(mixed $expected, mixed $actual, string $label): void
    {
        if ($expected !== $actual) {
            throw new \RuntimeException($label . ': expected ' . var_export($expected, true) . ', got ' . var_export($actual, true));
        }
    }

    require_once dirname(__DIR__) . '/setup.php';
    require_once dirname(__DIR__) . '/hook.php';

    $description = 'Controls persistent template bindings in GLPI, allowing native template selection based on category, active profile, and entity.';
    $metadata = plugin_version_sttemplatecontrol();
    assertIdentity('ST Template Control', $metadata['name'], 'Product name');
    assertIdentity('2.0.0', $metadata['version'], 'Version');
    assertIdentity('Service TIC (fork) / Curtis Conard', $metadata['author'], 'Authors');
    assertIdentity($description, $metadata['description'], 'Description');
    assertIdentity('sttemplatecontrol', PLUGIN_STTEMPLATECONTROL_I18N_DOMAIN, 'Gettext domain');
    assertIdentity('plugin:sttemplatecontrol', PluginSttemplatecontrolConfig::CONTEXT, 'Config context');
    assertIdentity($metadata['name'], PluginSttemplatecontrolConfig::getTypeName(), 'Config title');
    assertIdentity(true, plugin_sttemplatecontrol_check_prerequisites(), 'Minimum-version fixture');

    $composer = json_decode(file_get_contents(dirname(__DIR__) . '/composer.json'), true, 512, JSON_THROW_ON_ERROR);
    assertIdentity('servicetic/sttemplatecontrol', $composer['name'], 'Composer package name');
    assertIdentity($metadata['version'], $composer['version'], 'Composer version');
    assertIdentity($description, $composer['description'], 'Composer description');
    assertIdentity(['Service TIC (fork)', 'Curtis Conard'], array_column($composer['authors'], 'name'), 'Composer authors');
    echo "[OK] product name, version, authors, description and internal identity\n";

    global $PLUGIN_HOOKS;
    $PLUGIN_HOOKS = [];
    plugin_init_sttemplatecontrol();
    assertIdentity(true, $PLUGIN_HOOKS['csrf_compliant']['sttemplatecontrol'], 'CSRF registration');
    assertIdentity('front/config.form.php', $PLUGIN_HOOKS[Hooks::CONFIG_PAGE]['sttemplatecontrol'], 'Configuration route');
    assertIdentity(['addtabon' => [Config::class]], Plugin::$classes[PluginSttemplatecontrolConfig::class], 'Configuration class registration');
    assertIdentity(true, is_callable($PLUGIN_HOOKS[Hooks::PRE_SHOW_ITEM]['sttemplatecontrol']), 'Display callback');
    foreach ([Hooks::POST_PREPAREADD, Hooks::PRE_ITEM_UPDATE, Hooks::ITEM_UPDATE] as $hook) {
        foreach ([Ticket::class, Change::class, Problem::class] as $type) {
            assertIdentity(true, is_callable($PLUGIN_HOOKS[$hook]['sttemplatecontrol'][$type]), $hook . ' ' . $type);
        }
    }
    Plugin::$active = false;
    $PLUGIN_HOOKS = [];
    plugin_init_sttemplatecontrol();
    assertIdentity(['csrf_compliant' => ['sttemplatecontrol' => true]], $PLUGIN_HOOKS, 'Inactive plugin must not register handlers');
    Plugin::$active = true;
    echo "[OK] renamed hook registration and callable callbacks\n";

    // Legacy settings are deliberately not copied or deleted by this new identity.
    $legacy = 'plugin:sttemplatepriority';
    Config::$contexts = [$legacy => ['enabled' => 0, 'debug' => 1]];
    $previous = Config::$contexts[$legacy];
    assertIdentity(true, plugin_sttemplatecontrol_install(), 'Installation');
    assertIdentity(PluginSttemplatecontrolConfig::getDefaultConfig(), Config::$contexts[PluginSttemplatecontrolConfig::CONTEXT], 'New identity starts with defaults');
    assertIdentity($previous, Config::$contexts[$legacy], 'Legacy settings preserved');
    Config::$contexts[PluginSttemplatecontrolConfig::CONTEXT]['debug'] = 1;
    plugin_sttemplatecontrol_install();
    assertIdentity(1, Config::$contexts[PluginSttemplatecontrolConfig::CONTEXT]['debug'], 'Reinstallation preserves new settings');

    global $CFG_GLPI;
    $CFG_GLPI = ['root_doc' => '/glpi'];
    PluginSttemplatecontrolConfig::resetRuntimeCache();
    assertIdentity(true, PluginSttemplatecontrolConfig::showForConfig(new Config()), 'Config view');
    assertIdentity('@sttemplatecontrol/config.html.twig', TemplateRenderer::$template, 'Twig namespace');
    assertIdentity(PluginSttemplatecontrolConfig::class, TemplateRenderer::$parameters['config_class'], 'Form class');
    assertIdentity('plugin:sttemplatecontrol', TemplateRenderer::$parameters['config_context'], 'Form context');
    assertIdentity($description, TemplateRenderer::$parameters['i18n']['description'], 'Translated screen description');
    assertIdentity('/glpi/plugins/sttemplatecontrol/pics/service_tic_logo.png', TemplateRenderer::$parameters['marketing']['logo_url'], 'Local asset URL');
    Session::$update = false;
    PluginSttemplatecontrolConfig::showForConfig(new Config());
    assertIdentity(false, TemplateRenderer::$parameters['can_edit'], 'Read-only config view');
    Session::$read = false;
    $before = TemplateRenderer::$renders;
    assertIdentity(false, PluginSttemplatecontrolConfig::showForConfig(new Config()), 'Denied config view');
    assertIdentity($before, TemplateRenderer::$renders, 'Denied view must not render');
    assertIdentity(true, plugin_sttemplatecontrol_uninstall(), 'Uninstallation');
    assertIdentity(false, array_key_exists(PluginSttemplatecontrolConfig::CONTEXT, Config::$contexts), 'New settings removed');
    assertIdentity($previous, Config::$contexts[$legacy], 'Uninstallation leaves legacy settings intact');
    echo "[OK] configuration screen parameters and isolated install/uninstall contexts\n";
    echo "Todos os testes isolados de identidade passaram.\n";
}
