<?php

declare(strict_types=1);

namespace Glpi\Application\View {
    final class TemplateRenderer
    {
        public static function getInstance(): self
        {
            return new self();
        }

        /** @param array<string, mixed> $parameters */
        public function display(string $template, array $parameters = []): void
        {
        }
    }
}

namespace {
    define('GLPI_ROOT', dirname(__DIR__, 3));

    const READ = 1;
    const UPDATE = 2;

    class CommonGLPI
    {
        public static function createTabEntry(string $label, int $count = 0, ?string $class = null): string
        {
            return $label;
        }
    }

    class Config extends CommonGLPI
    {
        /** @var array<string, mixed> */
        public static array $stored = [];
        public static int $reads = 0;

        /** @return array<string, mixed> */
        public static function getConfigurationValues(string $context): array
        {
            ++self::$reads;
            return self::$stored;
        }
    }

    final class Session
    {
        public static function haveRight(string $right, int $level): bool
        {
            return true;
        }
    }

    require_once dirname(__DIR__) . '/inc/config.class.php';

    /** @throws \RuntimeException */
    function assertSameConfig(mixed $expected, mixed $actual, string $message): void
    {
        if ($expected !== $actual) {
            throw new \RuntimeException(
                $message . sprintf(
                    "\nEsperado: %s\nObtido: %s",
                    var_export($expected, true),
                    var_export($actual, true)
                )
            );
        }
    }

    $defaults = PluginSttemplatecontrolConfig::getDefaultConfig();
    assertSameConfig(
        [
            'enabled'                  => 1,
            'apply_ticket'             => 1,
            'apply_change'             => 1,
            'apply_problem'            => 1,
            'clear_template_on_update' => 1,
            'debug'                    => 0,
        ],
        $defaults,
        'Os valores padrão foram alterados inesperadamente.'
    );

    Config::$stored = [
        'enabled'      => '0',
        'apply_ticket' => '1',
        'debug'        => '1',
        'unknown'      => 'should-not-leak',
    ];
    Config::$reads = 0;
    PluginSttemplatecontrolConfig::resetRuntimeCache();

    $first = PluginSttemplatecontrolConfig::getConfig();
    $second = PluginSttemplatecontrolConfig::getConfig();

    assertSameConfig(1, Config::$reads, 'A configuração deveria ser lida apenas uma vez por requisição.');
    assertSameConfig($first, $second, 'O cache em memória retornou valores diferentes.');
    assertSameConfig(0, $first['enabled'], 'O valor salvo de enabled não foi aplicado.');
    assertSameConfig(1, $first['apply_change'], 'O padrão ausente não foi preservado.');
    assertSameConfig(1, $first['debug'], 'O valor salvo de debug não foi normalizado.');
    assertSameConfig(false, array_key_exists('unknown', $first), 'Uma chave desconhecida vazou para a configuração de execução.');

    $sanitized = PluginSttemplatecontrolConfig::configUpdate([
        'enabled'                  => '1',
        'apply_ticket'             => '0',
        'apply_change'             => 1,
        'apply_problem'            => '2',
        'clear_template_on_update' => true,
        'debug'                    => '-1',
        'config_class'             => PluginSttemplatecontrolConfig::class,
        'unexpected'               => '<script>alert(1)</script>',
    ]);

    assertSameConfig(
        [
            'enabled'                  => 1,
            'apply_ticket'             => 0,
            'apply_change'             => 1,
            'apply_problem'            => 0,
            'clear_template_on_update' => 1,
            'debug'                    => 0,
        ],
        $sanitized,
        'A sanitização da configuração não retornou apenas os campos booleanos permitidos.'
    );

    Config::$stored = ['enabled' => '1'];
    $after_update = PluginSttemplatecontrolConfig::getConfig();
    assertSameConfig(2, Config::$reads, 'configUpdate() deveria invalidar o cache em memória.');
    assertSameConfig(1, $after_update['enabled'], 'A configuração não foi recarregada após a atualização.');

    echo "[OK] config cache and sanitization\n";
    echo "Todos os testes isolados de configuração passaram.\n";
}
