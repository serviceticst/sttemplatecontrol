#!/usr/bin/env python3
from __future__ import annotations

import ast
import gettext
import re
from pathlib import Path

PLUGIN_DIR = Path(__file__).resolve().parent.parent
LOCALES_DIR = PLUGIN_DIR / 'locales'

EXPECTED_LOCALES = ['en_GB', 'en_US', 'pt_BR', 'es_ES', 'fr_FR']
EXPECTED_MSGIDS = [
    'Unable to identify the GLPI version.',
    'ST Template Control requires PHP %s or later.',
    'ST Template Control requires GLPI %s or later.',
    'ST Template Control has not yet been validated with GLPI %s or later.',
    'Implemented mode: GLPI 10 compatibility.',
    'The template stored on the ticket, change or problem is no longer treated as a forced template, restoring GLPI 10-style behaviour.',
    'GLPI resolves the native order again:',
    'Category → Active profile → Entity',
    'The native GLPI 10/11 code does not provide a direct template source linked to the user.',
    'The profile template is read from the active profile of the signed-in user. Therefore, this plugin does not expose a fictitious “User” option in the precedence order.',
    'Enable template compatibility',
    'Apply to tickets',
    'Apply to changes',
    'Apply to problems',
    'Clear persisted template link on updates',
    'Enable debug logging',
    'When debug logging is enabled, GLPI writes the file:',
    'Save',
    'Your profile has read permission, but not permission to change the general settings.',
    'Developed by:',
    'Visit the Service TIC website',
    'Open Service TIC links',
    'Service TIC logo',
    'QR code for Service TIC links',
    'Controls persistent template bindings in GLPI, allowing native template selection based on category, active profile, and entity.',
]

PLACEHOLDER_RE = re.compile(r'%(?:\d+\$)?[bcdeEfFgGosuxX]')


def fail(message: str) -> None:
    raise RuntimeError(message)


def read_simple_po(path: Path) -> dict[str, str]:
    """Read this plugin's singular, context-free PO entries using stdlib only."""
    result: dict[str, str] = {}
    msgid: str | None = None
    msgstr = ''
    state: str | None = None
    for raw in path.read_text(encoding='utf-8').splitlines() + ['']:
        line = raw.strip()
        if line.startswith('#,') and 'fuzzy' in line:
            fail(f'Fuzzy translation in {path.name}')
        if line.startswith('#'):
            continue
        if not line:
            if msgid is not None:
                if msgid in result:
                    fail(f'Duplicate msgid in {path.name}: {msgid}')
                result[msgid] = msgstr
            msgid, msgstr, state = None, '', None
        elif line.startswith('msgid '):
            msgid, state = ast.literal_eval(line[6:]), 'id'
        elif line.startswith('msgstr '):
            msgstr, state = ast.literal_eval(line[7:]), 'str'
        elif line.startswith('"'):
            value = ast.literal_eval(line)
            if state == 'id':
                msgid = (msgid or '') + value
            elif state == 'str':
                msgstr += value
            else:
                fail(f'Unexpected continuation in {path.name}')
        else:
            fail(f'Unsupported PO entry in {path.name}: {line}')
    return result


source_msgids = set()
source_pattern = re.compile(
    r"__\(\s*('(?:[^'\\]|\\.)*')\s*,\s*"
    r"(?:self::DOMAIN|PLUGIN_STTEMPLATECONTROL_I18N_DOMAIN)\s*\)"
)
for source in [PLUGIN_DIR / 'setup.php', PLUGIN_DIR / 'inc/config.class.php']:
    for match in source_pattern.finditer(source.read_text(encoding='utf-8')):
        source_msgids.add(ast.literal_eval(match.group(1)))
if source_msgids != set(EXPECTED_MSGIDS):
    fail('Translated PHP strings and expected catalog coverage differ')

for locale in EXPECTED_LOCALES:
    po = LOCALES_DIR / f'{locale}.po'
    mo = LOCALES_DIR / f'{locale}.mo'
    if not po.is_file():
        fail(f'Missing PO file: {po.name}')
    if not mo.is_file():
        fail(f'Missing MO file: {mo.name}')

    po_entries = read_simple_po(po)
    with mo.open('rb') as fh:
        catalog = gettext.GNUTranslations(fh)
    if catalog.info().get('project-id-version') != 'ST Template Control 2.0.0':
        fail(f'Incorrect project version in {locale}')
    if catalog.info().get('x-domain') != 'sttemplatecontrol':
        fail(f'Incorrect gettext domain in {locale}')
    if catalog.info().get('language') != locale:
        fail(f'Incorrect Language header in {locale}')

    for msgid in EXPECTED_MSGIDS:
        if msgid not in catalog._catalog:
            fail(f'Missing compiled translation in {locale}: {msgid}')
        if not po_entries.get(msgid):
            fail(f'Missing or empty source translation in {locale}: {msgid}')
        translated = catalog.gettext(msgid)
        if translated != po_entries[msgid]:
            fail(f'PO/MO mismatch in {locale}: {msgid}')
        if not translated:
            fail(f'Empty translation in {locale}: {msgid}')

        source_placeholders = sorted(PLACEHOLDER_RE.findall(msgid))
        translated_placeholders = sorted(PLACEHOLDER_RE.findall(translated))
        if source_placeholders != translated_placeholders:
            fail(
                f'Placeholder mismatch in {locale}: {msgid}\n'
                f'Expected {source_placeholders}, got {translated_placeholders}'
            )

# Explicitly verify the en_GB/en_US spelling distinction requested for v2.
with (LOCALES_DIR / 'en_GB.mo').open('rb') as fh:
    en_gb = gettext.GNUTranslations(fh)
with (LOCALES_DIR / 'en_US.mo').open('rb') as fh:
    en_us = gettext.GNUTranslations(fh)

behaviour_msgid = EXPECTED_MSGIDS[5]
if 'behaviour' not in en_gb.gettext(behaviour_msgid):
    fail('en_GB must retain British spelling: behaviour')
if 'behavior' not in en_us.gettext(behaviour_msgid):
    fail('en_US must use US spelling: behavior')

print(f'[OK] {len(EXPECTED_LOCALES)} locales and {len(EXPECTED_MSGIDS)} messages validated')
