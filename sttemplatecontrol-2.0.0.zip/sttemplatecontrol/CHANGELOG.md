# Changelog

## 2.0.0 — 2026-10-08

Consolidated package for publication as **ST Template Control**. Earlier local
packages used a different name; their preparation labels are not separate
ST Template Control releases.

### Identity and documentation

- Set the product name to **ST Template Control** and the package version to **2.0.0**.
- Set author metadata to **Service TIC (fork) / Curtis Conard**.
- Added the new description to plugin metadata, Composer, the configuration screen and both READMEs.
- Renamed the plugin directory, hooks, classes, constants, translation domain, Twig namespace, asset paths, log name and configuration context to `sttemplatecontrol`.
- Updated all five PO/MO catalogues and the POT template for the new identity and description.
- Updated English and Brazilian Portuguese READMEs, the LinkedIn draft, technical documentation and checks.
- Preserved the full Service TIC contact/social footer in both READMEs.
- Preserved the original upstream credits and GPL-3.0-or-later licence.
- Documented replacement of the previous `sttemplatepriority` package: deactivate the former plugin and configure the new one. Previous settings are not copied automatically.

### Retained functionality

- GLPI 11.x declared compatibility.
- Neutralise the persisted ITIL template during normal display without a database write merely from opening the page.
- Preserve explicit template previews and let GLPI use its native template-selection rules.
- Prevent persistent template bindings on new records.
- Optionally clear persisted template bindings after updates.
- Independently enable handling of tickets, changes and problems.
- Provide configuration, optional debug logging, five translation catalogues and the local Service TIC institutional panel.

No change to template-handling logic or configuration defaults. No plugin table,
bulk-update operation or database schema migration was added. Settings now use the
new `plugin:sttemplatecontrol` context, separately from the prior plugin identity.
